package com.touchflow.app.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface MacroDao {
    @Query("SELECT * FROM macros ORDER BY COALESCE(lastRunAt, createdAt) DESC")
    fun observeMacros(): Flow<List<MacroEntity>>

    @Query("SELECT COUNT(*) FROM macros")
    fun observeCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM macros")
    suspend fun observeCountOnce(): Int

    @Insert
    suspend fun insert(macro: MacroEntity): Long

    @Query("SELECT * FROM actions WHERE macroId = :macroId ORDER BY orderIndex")
    suspend fun getActions(macroId: Long): List<ActionEntity>

    @Insert
    suspend fun insertActions(actions: List<ActionEntity>)

    @Query("UPDATE macros SET lastRunAt = :time, runCount = runCount + 1 WHERE id = :id")
    suspend fun markRun(id: Long, time: Long)

    @Query("DELETE FROM macros WHERE id = :id")
    suspend fun delete(id: Long)
}
