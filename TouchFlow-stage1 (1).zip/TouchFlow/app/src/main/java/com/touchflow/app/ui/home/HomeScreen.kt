package com.touchflow.app.ui.home

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.touchflow.app.ui.theme.TfColors

@Composable
fun HomeScreen(vm: HomeViewModel = viewModel()) {
    val ui by vm.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val last = ui.macros.firstOrNull()

    LazyColumn(
        modifier = Modifier.fillMaxSize().background(TfColors.Background).statusBarsPadding(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item {
            Text("TOUCHFLOW", style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Black),
                color = TfColors.Cyan)
            Text("Auto Clicker & Macro Recorder", color = TfColors.TextSecondary)
        }

        // Статус разрешения (центр разрешений — этап 3)
        item {
            val ok = ui.accessibilityReady
            Card(
                colors = CardDefaults.cardColors(containerColor = TfColors.Surface),
                border = BorderStroke(1.dp, TfColors.Border),
                shape = RoundedCornerShape(18.dp),
            ) {
                Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(if (ok) Icons.Filled.CheckCircle else Icons.Filled.Warning, null,
                        tint = if (ok) TfColors.Ok else TfColors.Warn)
                    Column(Modifier.weight(1f).padding(start = 12.dp)) {
                        Text(if (ok) "Сервис жестов включён" else "Нужно включить сервис жестов",
                            fontWeight = FontWeight.SemiBold)
                        Text("Нужен только для воспроизведения ваших касаний.", color = TfColors.TextSecondary,
                            style = MaterialTheme.typography.bodySmall)
                    }
                    if (!ok) OutlinedButton(onClick = {
                        context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    }) { Text("Открыть") }
                }
            }
        }

        // Карточка быстрого запуска
        item {
            Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp)).background(TfColors.AccentGradient).padding(20.dp)) {
                Column {
                    Text("Быстрый запуск", color = TfColors.TextPrimary, fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleLarge)
                    Text(last?.name ?: "Сценариев пока нет", color = TfColors.TextPrimary)
                    Text("Циклов: ${ui.playback.cycles} · ${ui.playback.status}", color = TfColors.TextPrimary)
                    Spacer(Modifier.height(12.dp))
                    if (ui.playback.running) {
                        Button(onClick = vm::stop, colors = ButtonDefaults.buttonColors(containerColor = TfColors.Background)) {
                            Icon(Icons.Filled.Stop, null); Text("  STOP")
                        }
                    } else {
                        Button(
                            onClick = { last?.let(vm::start) },
                            enabled = last != null,
                            colors = ButtonDefaults.buttonColors(containerColor = TfColors.Background),
                        ) { Icon(Icons.Filled.PlayArrow, null); Text("  START") }
                    }
                }
            }
        }

        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Макросов: ${ui.macroCount}", Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                Button(onClick = vm::createMacro) { Icon(Icons.Filled.Add, null); Text("  Новый сценарий") }
            }
        }

        items(ui.macros, key = { it.id }) { m ->
            Card(
                colors = CardDefaults.cardColors(containerColor = TfColors.SurfaceHigh),
                border = BorderStroke(1.dp, TfColors.Border),
                shape = RoundedCornerShape(18.dp),
            ) {
                Row(Modifier.fillMaxWidth().padding(start = 16.dp, top = 8.dp, bottom = 8.dp, end = 4.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(m.name, fontWeight = FontWeight.SemiBold)
                        Text("Запусков: ${m.runCount}", color = TfColors.TextSecondary,
                            style = MaterialTheme.typography.bodySmall)
                    }
                    IconButton(onClick = { vm.start(m) }, enabled = !ui.playback.running) {
                        Icon(Icons.Filled.PlayArrow, "Запустить", tint = TfColors.Cyan)
                    }
                    IconButton(onClick = { vm.delete(m) }) {
                        Icon(Icons.Filled.Delete, "Удалить", tint = TfColors.TextSecondary)
                    }
                }
            }
        }
    }
}
