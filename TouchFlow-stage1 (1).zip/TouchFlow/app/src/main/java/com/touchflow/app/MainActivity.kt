package com.touchflow.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.touchflow.app.ui.navigation.TouchFlowNavHost
import com.touchflow.app.ui.theme.TouchFlowTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { TouchFlowTheme { TouchFlowNavHost() } }
    }
}
