package com.touchflow.app.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

object TfColors {
    val Background = Color(0xFF0B0B10)
    val Surface = Color(0xFF16161F)
    val SurfaceHigh = Color(0xFF1F1F2C)
    val Border = Color(0xFF2B2B3B)
    val Violet = Color(0xFF7C4DFF)
    val Blue = Color(0xFF3D5AFE)
    val Cyan = Color(0xFF40C4FF)
    val TextPrimary = Color(0xFFF2F2F7)
    val TextSecondary = Color(0xFF9A9AB0)
    val Ok = Color(0xFF4ADE80)
    val Warn = Color(0xFFFFB74D)

    val AccentGradient = Brush.linearGradient(listOf(Violet, Blue, Cyan))
}

private val TfDarkScheme = darkColorScheme(
    primary = TfColors.Violet,
    secondary = TfColors.Cyan,
    tertiary = TfColors.Blue,
    background = TfColors.Background,
    surface = TfColors.Surface,
    surfaceVariant = TfColors.SurfaceHigh,
    onBackground = TfColors.TextPrimary,
    onSurface = TfColors.TextPrimary,
    onSurfaceVariant = TfColors.TextSecondary,
    outline = TfColors.Border,
)

private val TfShapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(26.dp),
)

@Composable
fun TouchFlowTheme(content: @Composable () -> Unit) {
    // Этап 2 добавит светлую/авто темы из настроек; пока — премиальная тёмная.
    MaterialTheme(colorScheme = TfDarkScheme, shapes = TfShapes, content = content)
}
