package com.touchflow.app.service

import android.os.SystemClock
import com.touchflow.app.data.db.ActionEntity
import com.touchflow.app.data.db.MacroEntity
import com.touchflow.app.domain.LoopMode
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Воспроизведение сценария: цикл, паузы, остановка в любой момент. */
object PlaybackEngine {

    data class State(
        val running: Boolean = false,
        val cycles: Int = 0,
        val status: String = "Готов",
    )

    private val _state = MutableStateFlow(State())
    val state: StateFlow<State> = _state.asStateFlow()

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null

    fun start(macro: MacroEntity, actions: List<ActionEntity>, onFinished: () -> Unit = {}) {
        if (job?.isActive == true) return
        val service = TouchFlowAccessibilityService.instance
        if (service == null) {
            _state.value = State(status = "Включите сервис специальных возможностей")
            return
        }
        val steps = actions.filter { it.enabled }
        if (steps.isEmpty()) {
            _state.value = State(status = "В сценарии нет действий")
            return
        }
        job = scope.launch {
            _state.value = State(running = true, status = "Запуск…")
            val startedAt = SystemClock.elapsedRealtime()
            var cycles = 0
            try {
                delay(macro.startDelayMs)
                while (isActive) {
                    _state.value = _state.value.copy(status = "Выполняется")
                    for (a in steps) {
                        delay(a.delayBeforeMs)
                        val live = TouchFlowAccessibilityService.instance
                            ?: throw IllegalStateException("Сервис отключён")
                        val ok = withContext(Dispatchers.Main) { live.perform(a) }
                        if (!ok) { _state.value = _state.value.copy(status = "Жест отменён системой") }
                    }
                    cycles++
                    _state.value = _state.value.copy(cycles = cycles)
                    if (shouldStop(macro, cycles, startedAt)) break
                    delay(macro.cycleDelayMs)
                }
                _state.value = State(running = false, cycles = cycles, status = "Завершено")
            } catch (e: kotlinx.coroutines.CancellationException) {
                _state.value = State(running = false, cycles = cycles, status = "Остановлено")
                throw e
            } catch (e: Exception) {
                _state.value = State(running = false, cycles = cycles, status = e.message ?: "Ошибка")
            } finally {
                onFinished()
            }
        }
    }

    fun stop() { job?.cancel() }

    private fun shouldStop(m: MacroEntity, cycles: Int, startedAt: Long): Boolean =
        when (LoopMode.valueOf(m.loopMode)) {
            LoopMode.ONCE -> true
            LoopMode.COUNT -> cycles >= m.loopCount
            LoopMode.INFINITE -> false
            LoopMode.DURATION -> SystemClock.elapsedRealtime() - startedAt >= m.maxDurationMs
        }
}
