package com.touchflow.app.domain

enum class ActionType { TAP, SWIPE, PAUSE }

enum class LoopMode { ONCE, COUNT, INFINITE, DURATION }

/** Единицы времени SmartTimer с допустимыми диапазонами из ТЗ. */
enum class TimeUnitType(val millis: Long, val min: Long, val max: Long) {
    MS(1L, 1, 1000),
    SEC(1_000L, 1, 60),
    MIN(60_000L, 1, 60),
    HOUR(3_600_000L, 1, 24),
    DAY(86_400_000L, 1, 365);

    fun toMillis(value: Long): Long = value.coerceIn(min, max) * millis
}
