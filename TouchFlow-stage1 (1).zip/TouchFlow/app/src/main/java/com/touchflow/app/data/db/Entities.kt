package com.touchflow.app.data.db

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "macros")
data class MacroEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val description: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val lastRunAt: Long? = null,
    val loopMode: String = "ONCE",          // см. domain.LoopMode
    val loopCount: Int = 1,
    val maxDurationMs: Long = 0,
    val startDelayMs: Long = 0,
    val cycleDelayMs: Long = 0,
    val runCount: Int = 0,
)

@Entity(
    tableName = "actions",
    foreignKeys = [ForeignKey(
        entity = MacroEntity::class,
        parentColumns = ["id"],
        childColumns = ["macroId"],
        onDelete = ForeignKey.CASCADE,
    )],
    indices = [Index("macroId")],
)
data class ActionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val macroId: Long,
    val orderIndex: Int,
    val type: String,                        // см. domain.ActionType
    val label: String = "",
    val colorArgb: Int = 0xFF7C4DFF.toInt(),
    val x1: Float = 0f,
    val y1: Float = 0f,
    val x2: Float = 0f,
    val y2: Float = 0f,
    val durationMs: Long = 50,               // длительность нажатия / свайпа / паузы
    val delayBeforeMs: Long = 0,             // пауза перед действием
    val enabled: Boolean = true,
)
