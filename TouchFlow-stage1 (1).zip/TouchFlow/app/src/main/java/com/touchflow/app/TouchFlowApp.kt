package com.touchflow.app

import android.app.Application
import androidx.room.Room
import com.touchflow.app.data.db.AppDatabase

class TouchFlowApp : Application() {
    val db: AppDatabase by lazy {
        Room.databaseBuilder(this, AppDatabase::class.java, "touchflow.db").build()
    }
}
