package com.touchflow.app.ui.home

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.touchflow.app.TouchFlowApp
import com.touchflow.app.data.db.MacroEntity
import com.touchflow.app.service.PlaybackEngine
import com.touchflow.app.service.TouchFlowAccessibilityService
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class HomeUiState(
    val macros: List<MacroEntity> = emptyList(),
    val macroCount: Int = 0,
    val accessibilityReady: Boolean = false,
    val playback: PlaybackEngine.State = PlaybackEngine.State(),
)

class HomeViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = (app as TouchFlowApp).db.macroDao()

    val state: StateFlow<HomeUiState> = combine(
        dao.observeMacros(),
        dao.observeCount(),
        TouchFlowAccessibilityService.connected,
        PlaybackEngine.state,
    ) { macros, count, acc, pb -> HomeUiState(macros, count, acc, pb) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), HomeUiState())

    /** Создаёт пустой сценарий; редактор действий появится на этапах 4–6. */
    fun createMacro() = viewModelScope.launch {
        val n = dao.observeCountOnce() + 1
        dao.insert(MacroEntity(name = "Сценарий $n"))
    }

    fun start(macro: MacroEntity) = viewModelScope.launch {
        val actions = dao.getActions(macro.id)
        PlaybackEngine.start(macro, actions) {
            viewModelScope.launch { dao.markRun(macro.id, System.currentTimeMillis()) }
        }
    }

    fun stop() = PlaybackEngine.stop()

    fun delete(macro: MacroEntity) = viewModelScope.launch { dao.delete(macro.id) }
}
