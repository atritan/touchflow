package com.touchflow.app.data.db

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(entities = [MacroEntity::class, ActionEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun macroDao(): MacroDao
}
