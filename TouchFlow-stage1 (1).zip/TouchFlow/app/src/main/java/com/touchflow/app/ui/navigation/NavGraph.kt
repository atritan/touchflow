package com.touchflow.app.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.touchflow.app.ui.home.HomeScreen

object Routes {
    const val HOME = "home"
    // Следующие этапы: PERMISSIONS, EDITOR, TIMELINE, LIBRARY, STATS, SETTINGS
}

@Composable
fun TouchFlowNavHost() {
    val nav = rememberNavController()
    NavHost(navController = nav, startDestination = Routes.HOME) {
        composable(Routes.HOME) { HomeScreen() }
    }
}
