package com.touchflow.app.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent
import com.touchflow.app.data.db.ActionEntity
import com.touchflow.app.domain.ActionType
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/**
 * Официальный механизм Android для воспроизведения касаний: dispatchGesture.
 * Сервис не читает содержимое экрана (canRetrieveWindowContent=false) и не слушает события.
 */
class TouchFlowAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        instance = this
        _connected.value = true
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        _connected.value = false
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit
    override fun onInterrupt() = Unit

    /** Выполняет одно действие. Возвращает true, если система довела жест до конца. */
    suspend fun perform(action: ActionEntity): Boolean {
        if (action.type == ActionType.PAUSE.name) return true
        val path = Path().apply {
            moveTo(action.x1, action.y1)
            if (action.type == ActionType.SWIPE.name) lineTo(action.x2, action.y2)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0, action.durationMs.coerceAtLeast(1))
        val gesture = GestureDescription.Builder().addStroke(stroke).build()

        return suspendCancellableCoroutine { cont ->
            val accepted = dispatchGesture(gesture, object : GestureResultCallback() {
                override fun onCompleted(g: GestureDescription?) { if (cont.isActive) cont.resume(true) }
                override fun onCancelled(g: GestureDescription?) { if (cont.isActive) cont.resume(false) }
            }, null)
            if (!accepted && cont.isActive) cont.resume(false)
        }
    }

    companion object {
        @Volatile var instance: TouchFlowAccessibilityService? = null
            private set
        private val _connected = MutableStateFlow(false)
        val connected: StateFlow<Boolean> = _connected.asStateFlow()
    }
}
